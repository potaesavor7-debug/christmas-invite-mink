
'use strict';

// Replace the below with your deployed Google Apps Script Web App URL
// Example: const GAS_ENDPOINT = 'https://script.google.com/macros/s/AKfycbx.../exec';
const GAS_ENDPOINT = 'REPLACE_WITH_DEPLOYED_GAS_URL';

function $(sel){return document.querySelector(sel)}

// open modal handlers
$('#btnAccept').addEventListener('click',()=>{
  document.getElementById('qrModal').setAttribute('aria-hidden','false');
});
$('#btnDecline').addEventListener('click',()=>{
  document.getElementById('declineModal').setAttribute('aria-hidden','false');
});

// cancel
$('#cancel').addEventListener('click',()=>{document.getElementById('qrModal').setAttribute('aria-hidden','true');});
$('#cancelDecline').addEventListener('click',()=>{document.getElementById('declineModal').setAttribute('aria-hidden','true');});

// confirm join: send to GAS endpoint
$('#confirm').addEventListener('click', async ()=>{
  const name = $('#name').value.trim();
  const contact = $('#contact').value.trim();
  const amount = $('#amount').value.trim();
  if(!name){ alert('กรุณากรอกชื่อ-นามสกุล'); return; }
  const payload = { timestamp: new Date().toISOString(), name, contact, amount, answer: 'เข้าร่วม' };
  try{
    if(GAS_ENDPOINT === 'REPLACE_WITH_DEPLOYED_GAS_URL'){ alert('โปรดใส่ URL ของ Google Apps Script ในไฟล์ app.js'); return; }
    const res = await fetch(GAS_ENDPOINT, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    const data = await res.json();
    if(data && data.result === 'success'){
      alert('บันทึกคำตอบเรียบร้อย กรุณาสแกน QR เพื่อชำระเงิน');
      $('#qrModal').setAttribute('aria-hidden','true');
      // optionally go to accept.html
      window.location.href = 'accept.html';
    } else {
      alert('เกิดปัญหาในการบันทึกข้อมูล: ' + JSON.stringify(data));
    }
  }catch(err){
    alert('ไม่สามารถส่งข้อมูลได้: ' + err.message + '\nโปรดตรวจสอบ URL ของ Google Apps Script หรือการเชื่อมต่อ');
  }
});

// confirm decline
$('#confirmDecline').addEventListener('click', async ()=>{
  const name = $('#declineName').value.trim();
  const reason = $('#declineReason').value.trim();
  const payload = { timestamp: new Date().toISOString(), name, contact: '', amount:'', answer: 'ไม่สะดวก', reason };
  try{
    if(GAS_ENDPOINT === 'REPLACE_WITH_DEPLOYED_GAS_URL'){ alert('โปรดใส่ URL ของ Google Apps Script ในไฟล์ app.js'); return; }
    const res = await fetch(GAS_ENDPOINT, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    const data = await res.json();
    if(data && data.result === 'success'){
      alert('บันทึกคำตอบเรียบร้อย ขอบคุณค่ะ');
      $('#declineModal').setAttribute('aria-hidden','true');
      window.location.href = 'decline.html';
    } else {
      alert('เกิดปัญหาในการบันทึกข้อมูล: ' + JSON.stringify(data));
    }
  }catch(err){
    alert('ไม่สามารถส่งข้อมูลได้: ' + err.message);
  }
});
