
Mink Pleno Village — Christmas Invite (Production-ready files)
=================================================================

What's included:
- index.html      -> Landing invitation page (card design)
- accept.html     -> Dedicated QR page for payment (shows the QR image)
- decline.html    -> Thank-you page for declines
- styles.css      -> Styling matching the card design
- app.js          -> Client-side logic that POSTs responses to Google Sheets via Apps Script
- S__21266437.jpg -> The QR image you provided (PromptPay)
- apps_script.gs  -> Google Apps Script code to receive POST requests and write to Google Sheet
- README.md       -> This file

How to make it work (step-by-step)
----------------------------------

1) Host the files
   - You can upload these files to GitHub repo root (index.html present).
   - Then enable GitHub Pages on the repo (Settings -> Pages -> Source: main branch / root).
   - Or host on any static hosting (Netlify, Vercel, Firebase Hosting, any static web host).

2) Create Google Sheet and Apps Script endpoint
   - Create a new Google Sheet (e.g., "Mink Pleno Responses") and open it.
   - Note the Spreadsheet ID from the URL: https://docs.google.com/spreadsheets/d/SPREADSHEET_ID/edit
   - In that spreadsheet, open Extensions -> Apps Script.
   - In the Apps Script editor, remove default code and paste the contents of apps_script.gs (file included).
   - Replace SHEET_ID in apps_script.gs with your spreadsheet's ID and update SHEET_NAME if needed.
   - Save, then Deploy -> New deployment -> Select "Web app".
     - Description: e.g. "Mink Pleno RSVP API"
     - Execute as: Me
     - Who has access: Anyone (or Anyone with Google account)
   - Click Deploy and copy the Web app URL.

3) Connect client to the Apps Script URL
   - Open app.js and replace the string REPLACE_WITH_DEPLOYED_GAS_URL with the Web app URL you copied.
   - Save and re-upload the updated app.js.

4) Publish site & test
   - Open index.html from your host (or locally via file:// for quick testing).
   - Click "เข้าร่วม" -> fill name -> confirm. The script will POST to Apps Script which appends a new row in the spreadsheet.
   - Confirm that the new row appears in your Google Sheet.
   - After confirmation, users can scan the QR on accept.html to pay.

Notes / Security
----------------
- This setup uses Google Apps Script as a simple backend. If you set access to "Anyone, even anonymous" the endpoint can be called by anyone who has the URL. For small community events this is usually fine; for higher security consider requiring Google sign-in or adding a simple secret token check.
- Keep the spreadsheet shared only to organizers.
- The repo contains the QR image you provided. If you'd rather have a dynamic QR, generate and replace the image file or use a direct image URL in the HTML.

If you want, I can:
- Prepare a ready-to-upload ZIP with all files (I included it here).
- Or prepare a small guide with screenshots for deploying Google Apps Script and enabling GitHub Pages.
